﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exe4Lista3
{
    internal class Program
    {
        static void Main(string[] args)
        {
            for (int e = 5; e <= 5; e++)
            {
                for (int d = 1; d <= 10; d++)
                {
                    Console.WriteLine(e + " x " + d + " = " + e * d);
                }
            }
            Console.Read();
        }
    
    }
}
