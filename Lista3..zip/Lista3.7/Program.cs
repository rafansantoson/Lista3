﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exe7Lista3
{
    internal class Program
    {
        static void Main(string[] args)
        {
            for (int e = 1; e <= 20; e++)
            {
                Console.Write("Inicie a tabuada apertantdo qualquer tecla. ");
                Console.ReadLine();
                for (int c = 1; c <= 10; c++)

                {
                    Console.WriteLine(e + " x " + c + " = " + e * c);
                }
            }
        }
    }
}
