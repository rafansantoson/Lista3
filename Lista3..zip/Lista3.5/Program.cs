﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exe5Lista3
{
    internal class Program
    {
        static void Main(string[] args)
        {
            int tabuada;
            int b = 0;
            int d;


            do
            {
                Console.Clear();
                Console.WriteLine("Qual tabuada você quer ver? Apenas numeros positivos!!");
                tabuada = Convert.ToInt16(Console.ReadLine());
            } while (tabuada < b);
            for (int c = 1; c <= 10; c++)
            {
                Console.WriteLine(tabuada + " x " + c + " = " + tabuada * c);
            }
            Console.Read();
        }
    }
}
